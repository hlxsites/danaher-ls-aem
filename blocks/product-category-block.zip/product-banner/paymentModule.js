paymentModule.js
